# Order Storage Preview

This source package contains a custody-free FIFO storage kernel and an
authenticated example host. It does not custody tokens, match prices, or settle
trades. `OrderStorageKernel` is the default contiguous/global allocator;
`HashedOrderStorageKernel` is included only as an equivalent comparison baseline.
Version `0.4.0-lots.0` reports each fill's remaining quantity so an adapter can
enforce a residual policy. The kernel still assigns no monetary meaning to
`quantity` or `price`: the finance reference interprets them as integer lots
and an opaque `priceTick`/level ID. Currency conversion belongs to the host.

Solidity import:

```solidity
import "@monad-ac/order-storage-preview/examples/OrderBookHost.sol";
```

An order reference is `(hostAddress, marketId, handle)`. A handle by itself is
not globally unique. This preview is distributed as a locally-built tarball; it
has not been published to a registry or audited for production custody use.
