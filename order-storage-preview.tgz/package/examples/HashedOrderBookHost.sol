// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "../contracts/HashedOrderStorageKernel.sol";

/// Hashed-node baseline for OrderBookHost. Keep its external policy and ABI in
/// lockstep with the contiguous default so storage addressing is the comparison.
contract HashedOrderBookHost {
    using HashedOrderStorageKernel for bytes32;

    address public immutable admin;
    address public immutable matcher;
    uint256 public unrelatedValue = 0xdecafbad;

    error UnauthorizedMatcher(address caller);
    error UnauthorizedAdmin(address caller);
    error LengthMismatch();

    event MarketInitialized(bytes32 indexed marketId);
    event OrderRegistered(bytes32 indexed marketId, uint64 indexed price, uint96 indexed handle, address maker, uint96 quantity);
    event OrderCancelled(bytes32 indexed marketId, uint96 indexed handle, address indexed maker, uint96 quantity);
    event QuantityConsumed(bytes32 indexed marketId, uint64 indexed price, uint96 quantity);

    constructor(address admin_, address matcher_) {
        require(admin_ != address(0) && matcher_ != address(0), "role");
        admin = admin_;
        matcher = matcher_;
    }

    function initializeMarket(bytes32 marketId) external {
        if (msg.sender != admin) revert UnauthorizedAdmin(msg.sender);
        marketId.initialize();
        emit MarketInitialized(marketId);
    }

    function post(bytes32 marketId, uint64 price, uint96 quantity) external returns (uint96 handle) {
        handle = marketId.post(msg.sender, price, quantity);
        emit OrderRegistered(marketId, price, handle, msg.sender, quantity);
    }

    function cancel(bytes32 marketId, uint96 handle) external {
        uint96 quantity = marketId.cancel(msg.sender, handle);
        emit OrderCancelled(marketId, handle, msg.sender, quantity);
    }

    function refresh(
        bytes32 marketId,
        uint96[] calldata cancelHandles,
        uint64[] calldata prices,
        uint96[] calldata quantities
    ) external returns (uint96[] memory newHandles) {
        if (prices.length != quantities.length) revert LengthMismatch();
        for (uint256 i; i < cancelHandles.length; ++i) {
            uint96 quantity = marketId.cancel(msg.sender, cancelHandles[i]);
            emit OrderCancelled(marketId, cancelHandles[i], msg.sender, quantity);
        }
        newHandles = new uint96[](prices.length);
        for (uint256 i; i < prices.length; ++i) {
            uint96 handle = marketId.post(msg.sender, prices[i], quantities[i]);
            newHandles[i] = handle;
            emit OrderRegistered(marketId, prices[i], handle, msg.sender, quantities[i]);
        }
    }

    function consume(bytes32 marketId, uint64 price, uint96 quantity) external {
        if (msg.sender != matcher) revert UnauthorizedMatcher(msg.sender);
        marketId.consume(price, quantity);
        emit QuantityConsumed(marketId, price, quantity);
    }

    function order(bytes32 marketId, uint96 handle) external view returns (HashedOrderStorageKernel.Order memory) {
        return marketId.order(handle);
    }

    function level(bytes32 marketId, uint64 price) external view returns (uint96 head, uint96 tail) {
        return marketId.level(price);
    }

    function allocator(bytes32 marketId) external view returns (uint32 highWater, uint32 freeHead) {
        return marketId.allocator();
    }

    function storageNamespace(bytes32 marketId) external pure returns (bytes32 stateSlot, bytes32 nodes) {
        return (marketId.stateSlot(), marketId.nodeBase());
    }

    function storageNodeSlot(bytes32 marketId, uint32 index) external pure returns (bytes32) {
        return marketId.nodeSlot(index);
    }
}
